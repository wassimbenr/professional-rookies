#include "structs.h"
extern Gestion jeu;
extern Hero player;
extern Map map;
extern void centerScrollingOnPlayer(void);
extern void mapCollision(Hero *entity);
