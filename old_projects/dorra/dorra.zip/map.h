#include "structs.h"

extern Gestion jeu;
extern Map map;
extern Hero player;
