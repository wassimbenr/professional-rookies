#include "player.h"

void updatePlayer(void)
{
mapCollision(&player);
centerScrollingOnPlayer();
}
